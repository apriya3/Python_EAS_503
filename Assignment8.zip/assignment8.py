import operator
from datetime import datetime
import math
def ex1():
    """
    Reproduce ex1.tsv from 'AdmissionsCorePopulatedTable.txt'
    https://mkzia.github.io/eas503-notes/sql/sql_6_conditionals.html#conditionals
    Separate the columns by a tab
    """

    # BEGIN SOLUTION
    file = open('AdmissionsCorePopulatedTable.txt', 'r')
    admission = {}; sorted_admission = []
    for line in file.readlines()[1:]:
        month = int(line.split("\t")[2].split(" ")[0].split("-")[1].strip())
        if month == 1:
            if 'January' in admission.keys():
                admission['January'] += 1
            else:
                admission['January'] = 1
        elif month == 2:
            if 'February' in admission.keys():
                admission['February'] += 1
            else:
                admission['February'] = 1
        elif month == 3:
            if 'March' in admission.keys():
                admission['March'] += 1
            else:
                admission['March'] = 1
        elif month == 4:
            if 'April' in admission.keys():
                admission['April'] += 1
            else:
                admission['April'] = 1
        elif month == 5:
            if 'May' in admission.keys():
                admission['May'] += 1
            else:
                admission['May'] = 1
        elif month == 6:
            if 'June' in admission.keys():
                admission['June'] += 1
            else:
                admission['June'] = 1
        elif month == 7:
            if 'July' in admission.keys():
                admission['July'] += 1
            else:
                admission['July'] = 1
        elif month == 8:
            if 'August' in admission.keys():
                admission['August'] += 1
            else:
                admission['August'] = 1
        elif month == 9:
            if 'September' in admission.keys():
                admission['September'] += 1
            else:
                admission['September'] = 1
        elif month == 10:
            if 'October' in admission.keys():
                admission['October'] += 1
            else:
                admission['October'] = 1
        elif month == 11:
            if 'November' in admission.keys():
                admission['November'] += 1
            else:
                admission['November'] = 1
        elif month == 12:
            if 'December' in admission.keys():
                admission['December'] += 1
            else:
                admission['December'] = 1
    for i in admission:
        sorted_admission.append((i, admission[i]))
    sorted_admission.sort(key=lambda tup: (-1 * tup[1], tup[0]), reverse=False)
    #sorted_admission = dict( sorted(admission.items(), key=operator.itemgetter(1),reverse=True))
    with open("ex1.tsv", "w") as record_file:
        record_file.write("%s\t%s\n" % ('AdmissionMonth','AdmissionCount'))
        for index, record in enumerate(sorted_admission):
            if index!=len(sorted_admission) - 1:
                record_file.write("%s\t%s\n" % (record[0],record[1]))
            else:
                record_file.write("%s\t%s" % (record[0],record[1]))
    # END SOLUTION
ex1()

def ex2():
    """
    Repeat ex1 but add the Quarter column 
    This is the last SQL query on https://mkzia.github.io/eas503-notes/sql/sql_6_conditionals.html#conditionals
    Hint: https://stackoverflow.com/questions/60624571/sort-list-of-month-name-strings-in-ascending-order
    """

    # BEGIN SOLUTION
    calander = ['January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December']
    file = open('AdmissionsCorePopulatedTable.txt', 'r')
    admission = {}; quater = {}
    for line in file.readlines()[1:]:
        month = int(line.split("\t")[2].split(" ")[0].split("-")[1].strip())
        if month == 1:
            if 'January' in admission.keys():
                admission['January'] += 1
            else:
                admission['January'] = 1
                quater['January'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 2:
            if 'February' in admission.keys():
                admission['February'] += 1
            else:
                admission['February'] = 1
                quater['February'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 3:
            if 'March' in admission.keys():
                admission['March'] += 1
            else:
                admission['March'] = 1
                quater['March'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 4:
            if 'April' in admission.keys():
                admission['April'] += 1
            else:
                admission['April'] = 1
                quater['April'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 5:
            if 'May' in admission.keys():
                admission['May'] += 1
            else:
                admission['May'] = 1
                quater['May'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 6:
            if 'June' in admission.keys():
                admission['June'] += 1
            else:
                admission['June'] = 1
                quater['June'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 7:
            if 'July' in admission.keys():
                admission['July'] += 1
            else:
                admission['July'] = 1
                quater['July'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 8:
            if 'August' in admission.keys():
                admission['August'] += 1
            else:
                admission['August'] = 1
                quater['August'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 9:
            if 'September' in admission.keys():
                admission['September'] += 1
            else:
                admission['September'] = 1
                quater['September'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 10:
            if 'October' in admission.keys():
                admission['October'] += 1
            else:
                admission['October'] = 1
                quater['October'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 11:
            if 'November' in admission.keys():
                admission['November'] += 1
            else:
                admission['November'] = 1
                quater['November'] = ('Q'+str((month - 1)//3 + 1))
        elif month == 12:
            if 'December' in admission.keys():
                admission['December'] += 1
            else:
                admission['December'] = 1
                quater['December'] = ('Q'+str((month - 1)//3 + 1))
    with open("ex2.tsv", "w") as record_file:
        record_file.write("%s\t%s\t%s\n" % ('Quarter','AdmissionMonth','AdmissionCount'))
        for index, record in enumerate(calander):
            if index!=len(admission.keys()) - 1:
                record_file.write("%s\t%s\t%s\n" % (quater[record],record,admission[record]))
            else:
                record_file.write("%s\t%s\t%s" % (quater[record],record,admission[record]))
    # END SOLUTION
#ex2()

def ex3():
    """
    Reproduce 
    SELECT
        LabsCorePopulatedTable.PatientID,
        PatientCorePopulatedTable.PatientGender,
        LabName,
        LabValue,
        LabUnits,
        CASE
            WHEN PatientCorePopulatedTable.PatientGender = 'Male'
            AND LabValue BETWEEN 0.7
            AND 1.3 THEN 'Normal'
            WHEN PatientCorePopulatedTable.PatientGender = 'Female'
            AND LabValue BETWEEN 0.6
            AND 1.1 THEN 'Normal'
            ELSE 'Out of Range'
        END Interpretation
    FROM
        LabsCorePopulatedTable
        JOIN PatientCorePopulatedTable ON PatientCorePopulatedTable.PatientID = LabsCorePopulatedTable.PatientID
    WHERE
        LabName = 'METABOLIC: CREATININE'
    ORDER BY
        - LabValue

    using PatientCorePopulatedTable.txt and LabsCorePopulatedTable

    **** ADD  LabDateTime
    **** SORT BY Patient ID and then LabDateTime in ascending order 
    """
    # BEGIN SOLUTION
    lab_file = open('LabsCorePopulatedTable.txt', 'r')
    patient_file = open('PatientCorePopulatedTable.txt', 'r')
    gender = {}; data = []
    for line in patient_file.readlines()[1:]:   
        gender[line.split("\t")[0]] = line.split("\t")[1]
    for line in lab_file.readlines()[1:]:
        if line.split("\t")[2].strip() == 'METABOLIC: CREATININE':
            if gender[line.split("\t")[0].strip()] == 'Male' and 0.7<=float(line.split("\t")[3].strip())<=1.3:
                data.append((line.split("\t")[0].strip(), gender[line.split("\t")[0].strip()], line.split("\t")[2].strip(),line.split("\t")[3].strip(),line.split("\t")[4].strip(),line.split("\t")[5].strip(), 'Normal'))
            elif gender[line.split("\t")[0].strip()] == 'Female' and 0.6<=float(line.split("\t")[3].strip())<=1.1:
                data.append((line.split("\t")[0].strip(), gender[line.split("\t")[0].strip()], line.split("\t")[2].strip(),line.split("\t")[3].strip(),line.split("\t")[4].strip(),line.split("\t")[5].strip(), 'Normal'))
            else:
                data.append((line.split("\t")[0].strip(), gender[line.split("\t")[0].strip()], line.split("\t")[2].strip(),line.split("\t")[3].strip(),line.split("\t")[4].strip(),line.split("\t")[5].strip(), 'Out of Range'))
    data_sorted = sorted(data, key=operator.itemgetter(0, 5))
    #data_sorted = sorted(data, key = lambda x: x[0])
    #print(data_sorted)
    with open("ex3.tsv", "w") as record_file:
        record_file.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % ('PatientID','PatientGender','LabName','LabValue','LabUnits','LabDateTime','Interpretation'))
        for index, record in enumerate(data_sorted):
            if index!=len(data_sorted) - 1:
                record_file.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (record[0],record[1],record[2],record[3],record[4],record[5],record[6]))
            else:
                record_file.write("%s\t%s\t%s\t%s\t%s\t%s\t%s" % (record[0],record[1],record[2],record[3],record[4],record[5],record[6]))
    # END SOLUTION
#ex3()


def ex4():
    """
    Reproduce this
    WITH AGE AS (
        SELECT 
            PATIENTID,
            ROUND((JULIANDAY('NOW') - JULIANDAY(PATIENTDATEOFBIRTH))/365.25) AGE
        FROM 
            PATIENTCOREPOPULATEDTABLE
    )
    SELECT 
        CASE 
            WHEN AGE < 18 THEN 'YOUTH'
            WHEN AGE BETWEEN 18 AND 35 THEN 'YOUNG ADULT'
            WHEN AGE BETWEEN 36 AND 55 THEN 'ADULT'
            WHEN AGE >= 56 THEN 'SENIOR'
        END AGE_RANGE,
        COUNT(*) AGE_RANGE_COUNT
    FROM 
        AGE
    GROUP BY AGE_RANGE
    ORDER BY AGE

    ****** VERY IMPORTANT: Use the Date: 2022-12-11 as today's date!!!! VERY IMPORTANT otherwise your result will change everyday!
    ****** VERY IMPORTANT divide the number of days by 365.25; to get age do math.floor(delta.days/365.25), where delta days is now-dob

    """
    # BEGIN SOLUTION
    age_criteria = [0,0,0,0]
    age_labels = ['YOUTH','YOUNG ADULT','ADULT','SENIOR']
    patient_file = open('PatientCorePopulatedTable.txt', 'r')
    for line in patient_file.readlines()[1:]:   
        age = datetime.strptime('2022-12-11', '%Y-%m-%d') - datetime.strptime(line.split("\t")[2].split(" ")[0], '%Y-%m-%d')
        cal_age = math.floor(age.days/365.25)
        if cal_age < 18: age_criteria[0] += 1
        elif 18 <= cal_age <= 35: age_criteria[1] += 1
        elif 36 <= cal_age <= 55: age_criteria[2] += 1
        elif cal_age >= 56: age_criteria[3] += 1
    with open("ex4.tsv", "w") as record_file:
        record_file.write("%s\t%s\n" % ('AGE_RANGE','AGE_RANGE_COUNT'))
        for index, record in enumerate(age_criteria):
            if record != 0:
                if index!=len(age_criteria) - 1:
                    record_file.write("%s\t%s\n" % (age_labels[index],record))
                else:
                    record_file.write("%s\t%s" % (age_labels[index],record))
    # END SOLUTION
#ex4()