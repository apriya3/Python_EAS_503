from re import L

def ex1(password):
    # In this exercise you will complete this function to determine whether or not
    # a password is good. We will define a good password to be a one that is at least
    # 8 characters long and contains at least one uppercase letter, at least one lowercase
    # letter, at least one number, and at least one of the following special characters (!, @, #, $, ^).
    # This function should return True if the password
    # passed to it as its only parameter is good. Otherwise it should return False.
        #
    # input: password (str)
    # output: True or False (bool)
    # BEGIN SOLUTION
    password_strength = [False, False, False]
    special_characters = ['!','@','#','$','^']
    for i in password:
        if ord('A') <= ord(i) <= ord('Z'):password_strength[0] = True
        if ord('a') <= ord(i) <= ord('z'):password_strength[1] = True
        for sc in special_characters:
            if i == sc:
                password_strength[2] = True
    if password_strength[0] == password_strength[1] == password_strength[2] == True:
        return True
    return False
    # END SOLUTION
#print(ex1("AnnuP$"))

def ex2(sentence):
    import string
    # Complete this function to calculate the average
    # word length in a sentence
    # Input: sentence
    # Output: average word length in sentence
    # Hint: count punctuations with whatever word they are `touching`
    # Hint: round  the average to two decimal places
    # BEGIN SOLUTION
    words = sentence.split(" ")
    word_len = 0; word_count = 0
    for w in words:
        if w not in string.punctuation:
            word_len += len(w); word_count += 1
    return round(word_len/word_count, 2)
    # END SOLUTION
#print(ex2("Hello , Annu Priya."))


def ex3(filename):
    # Complete this function to count the number of lines, words, and chars in a file.
    # Input: filename
    # Output: a tuple with line count, word count, and char count -- in this order
    # BEGIN SOLUTION
    file = open(filename, "r")
    lines = []; words = []; number_lines = 0; number_words = 0; number_chars = 0
    for line in file:
        lines = line.strip("\n")
        words = lines.split()
        number_lines += 1
        number_words += len(words)
        number_chars += len(line)
    return (number_lines, number_words, number_chars)
    # END SOLUTION
#print(ex3('ex3_data.txt'))

def ex4(apr):
    # Complete this function to use a while loop to determine how long it takes for an investment
    # to double at a given interest rate. The input to this function, apr, is the annualized interest rate
    # and the output is the number of years it takes an investment to double. Note: The amount of the initial
    # investment (principal) does not matter; you can use $1.
    # Hint: principal is the amount of money being invested.
    # apr is the annual percentage rate expressed as a decimal number.
    # Relationship: value after one year is given by principal * (1+ apr)

    # BEGIN SOLUTION
    import math
    n = 1
    while(math.log(2) >= (n * math.log(1 + apr))):
        n +=1
    return n
    # END SOLUTION
#print(ex4(0.06))

def ex5(n):
    # Complete this function to return the number of steps taken to reach 1 in
    # the Collatz sequence (https://en.wikipedia.org/wiki/Collatz_conjecture) given in

    # BEGIN SOLUTION
    if n == 1:return 0
    if n%2 == 0:return 1 + ex5(n//2)
    else:return 1 + ex5((3*n) + 1)
    # END SOLUTION
#print(ex5(11))


def ex6(n):
    # A positive whole number > 2 is prime if no number between 2 and sqrt(n)
    # (include) evenly divides n. Write a program that accepts a value of n as
    # input and determine if the value is prime. If n is not prime, your program should
    # return False (boolean) as soon as it finds a value that evenly divides n.
    # Hint: if number is 2, return False

    import math

    # BEGIN SOLUTION
    if(n == 3 or n == 5) or (n%2 != 0 and n%3 != 0) and (n%2 != 0 and n%5 != 0) and (n%3 != 0 and n%5 != 0):
        return True
    for i in range(2,int(math.sqrt(n))):
        if(n%i == 0):
            return False
    return False
    # END SOLUTION
#print(ex6(25))

def ex7(n):
    # Complete this function to return all the primes as a list less than or equal to n
    # Input: n
    # Output: a list of numbers
    # hint use ex6

    # BEGIN SOLUTION
    prime = []
    for i in range(3,n+1):
        if(i == 2 or i == 5 or i == 3):
            prime.append(i)
        elif(i%2 != 0 and i%3 != 0) and (i%2 != 0 and i%5 != 0) and (i%3 != 0 and i%5 != 0):
            prime.append(i)
    return prime
    # END SOLUTION
#print(ex7(10))

def ex8(m, n):
    # Complete this function to determine the greatest common divisor (GCD).
    # The GCD of two values can be computed using Euclid's algorithm. Starting with the values
    # m and n, we repeatedly apply the formula: n, m = m, n%m until m is 0. At this point, n is the GCD
    # of the original m and n.
    # Inputs: m and n which are both natural numbers
    # Output: gcd

    # BEGIN SOLUTION
    greater = 0; smaller = 0; r = 0
    if(m>n): greater = m; smaller = n
    else: greater = n; smaller = m
    r = greater%smaller
    if r == 0:
        return(smaller)
    else:
        return ex8(smaller,r)
    # END SOLUTION
#print(ex8(25,75))

def ex9(filename):
    # Complete this function to read grades from a file and determine the student with the highest average
    # test grades and the lowest average test grades.
    # Input: filename
    # Output: a tuple containing four elements: name of student with highest average, their average,
    # name of the student with the lowest test grade, and their average. Example ('Student1', 99.50, 'Student5', 65.50)
    # Hint: Round to two decimal places

    # BEGIN SOLUTION
    student_avg = {}; highest_avg= 0; lowest_avg= 0 
    file = open(filename,"r")
    for f in file.readlines():
        if f[0] != '\n':
            student = f.split(",")
            marks = sum(int(x) for x in student[1:])
            student_avg[student[0]] = round(marks/len(student[1:]), 2)
    lowest_avg = min(student_avg.values())
    highest_avg = max(student_avg.values())
    lowest_avg_name = list(student_avg.keys())[list(student_avg.values()).index(lowest_avg)]
    highest_avg_name = list(student_avg.keys())[list(student_avg.values()).index(highest_avg)]
    return (highest_avg_name, highest_avg, lowest_avg_name, lowest_avg)
    # END SOLUTION
#print(ex9("ex9_data.txt"))

def ex10(data, num_outliers):
    # When analyzing data collected as a part of a science experiment it
    # may be desirable to remove the most extreme values before performing
    # other calculations. Complete this function which takes a list of
    # values and an non-negative integer, num_outliers, as its parameters.
    # The function should create a new copy of the list with the num_outliers
    # largest elements and the num_outliers smallest elements removed.
    # Then it should return teh new copy of the list as the function's only
    # result. The order of the elements in the returned list does not have to
    # match the order of the elements in the original list.
    # input1: data (list)
    # input2: num_outliers (int)
    # output: list

    # BEGIN SOLUTION
    new_list = sorted(data.copy())
    count = 0
    while(count<num_outliers):
        length = len(new_list) -1
        new_list.remove(new_list[0])
        length -= 1
        new_list.remove(new_list[length])
        count += 1
    return new_list
    # END SOLUTION
# import random
# random.seed(1234)
# data = [random.randint(50, 150) for ele in range(100)]
# data[45] = 1
# data[46] = 2
# data[90] = 250
# data[34] = 300
#print(ex10(data, 2))

def ex11(words):
    # Complete this function to remove duplicates from the words list using a loop
    # input: words (list)
    # output: a list without duplicates
    # MUST USE loop and NOT set!
    # Preserve order

    # BEGIN SOLUTION
    word = []
    for i in words:
        if i not in word:
            word.append(i)
    return word
    # END SOLUTION
#print(ex11(['Hello', 'Hello', 'Annu', 'Priya']))

def ex12(n):
    # A proper divisor of a  positive integer, n, is a positive integer less than n which divides
    # evenly into n. Complete this function to compute all the proper divisors of a positive
    # integer. The integer is passed to this function as the only parameter. The function will
    # return a list of containing all of the proper divisors as its only result.

    # input: n (int)
    # output: list

    # BEGIN SOLUTION
    proper_divisors = []
    for i in range(1,n):
        if n%i == 0:
            proper_divisors.append(i)
    return proper_divisors
    # END SOLUTION
#print(ex12(12))


def ex13(n):
    # An integer, n, is said to be perfect when the sum of all of the proper divisors
    # of n is equal to n. For example, 28 is a perfect number because its proper divisors
    # are 1, 2, 4, 7, and 14 = 28
    # Complete this function to determine if a the number a perfect number or not.
    # input: n (int)
    # output: True or False (bool)

    # BEGIN SOLUTION
    proper_divisors = []
    for i in range(1,n):
        if n%i == 0:
            proper_divisors.append(i)
    if sum(proper_divisors) == n:
        return True
    return False
    # END SOLUTION
#print(ex13(28))

def ex14(points):
    # Complete this function to determine the best line.
    # https://www.varsitytutors.com/hotmath/hotmath_help/topics/line-of-best-fit
    # input: points (list of tuples contain x, y values)
    # output: (m, b) # round both values to two decimal places

    # BEGIN SOLUTION
    mean_X = 0 ;mean_Y = 0
    val = [];val2 = []
    for i in points:
        mean_X += i[0]; mean_Y += i[1]
    mean_X /= len(points); mean_Y /= len(points)
    for i in points:
        val.append((i[0] - mean_X) * (i[1] - mean_Y))
        val2.append((i[0] - mean_X  ) ** 2)
    m = round(sum(val)/sum(val2),3)
    return (round(m,2), round(mean_Y - (m * mean_X),2))
    # END SOLUTION
#print(ex14([(8,3),(2,10),(11,3),(6,6),(5,8),(4,12),(12,1),(9,4),(6,9),(1,14)]))

def ex15(title, header, data, filename):
    # This problem is hard.
    # Open up ex15_*_solution.txt and look at the output based on the input parameters, which
    # can be found in the test_assignment4.py file
    # Function inputs: 
    # title -- title of the table -- a string
    # header -- header of the table  -- a tuple
    # data -- rows of data, which is a tuple of tuples
    # filename -- name of file to write the table to
    # Your job is to create the table in the file and write it to `filename`
    # Note that you need to dynamically figure out the width of each column based on 
    # maximum possible length based on the header and data. This is what makes this problem hard. 
    # Once you have determined the maximum length of each column, make sure to pad it with 1 space
    # to the right and left. Center align all the values. 
    # OUTPUT: you are writing the table to a file

    # BEGIN SOLUTION
    #Declare Length to get the maximum length in data
    length = [0] * len(header)
    
    #Declare data_string for data part
    data_string = "| "
    
    # To understand the maximum data length
    for i in range(len(data)):
        index = 0
        for j in data[i]:
            if length[index]<len(str(j)):
                length[index] = len(str(j))
            index += 1 

    #Declare Length to get the maximum length in header 
    header_length = [0] * len(header)
    
    # To understand the maximum header length    
    index = 0
    for i in header:
        if header_length[index]<len(str(i)):
            header_length[index] = len(str(i))
        index += 1

    # Get the Maximum length in dat and header
    for i in range(len(header_length)):
        if header_length[i] > length[i]:
            length[i] = header_length[i]

    # Get the entire data for Data_String
    for i in range(len(data)):
        index = 0
        for j in data[i]:
            margin = length[index] - len(str(j))
            left = 0; right = 0
            left_string = ""; right_string = ""
            if margin%2 ==0:
                left = margin//2; right = margin//2
            else:
                left = margin//2; right = margin - left
            for m in range(left): 
                left_string += " "
            for n in range(right): 
                right_string += " "
            data_string += left_string + str(j) + right_string + " |"
            if(index!= len(data[i]) - 1):
                data_string += " "
            index += 1 

        # Append data_string for new line formatting
        if(i!=len(data) - 1):
            data_string += "\n| "
    
    # Get the entire data for Header_String
    header_string = "| "
    index = 0
    for i in header:
        margin = length[index] - len(i)
        left = 0; right = 0
        left_string = ""; right_string = ""
        if margin%2 ==0:
            left = margin//2; right = margin//2
        else:
            left = margin//2; right = margin - left
        for m in range(left): 
            left_string += " "
        for n in range(right): 
            right_string += " "
        header_string += left_string + i + right_string + " |"
        if index != len(header) - 1:
                header_string += " "
        index += 1
    
    # To build the border line of the table
    line_string = ''
    for i in range(len(header_string)):
        line_string += "-"
    
    # To build the bottom border line of the table
    line_update_string = str(line_string)
    for i in range(len(header_string)):
        if header_string[i] == '|':
            line_update_string = line_update_string[:i] + "+" + line_update_string[i+1:]
    
    # Get the entire data for Title_String
    title_string ="|"
    title_string += title.center(len(header_string) - 2) + "|"
    
    # To concatenate all the string
    final_string = line_string + "\n" + title_string + "\n" + line_update_string + "\n" + header_string + "\n" + line_update_string + "\n" + data_string + "\n" + line_update_string
    
    # To wtite the data to the filename given
    file = open(filename, "w")
    file.write(final_string)
    file.close()
    # END SOLUTION
# title = 'Cereal Yields (kg/ha)'
# header = ('Country', '1980', '1990', '2000', '2010')
# data = (
#     ('China', 2937, 4321, 4752, 5527),
#     ('Germany', 4225, 5411, 6453, 6718),
#     ('United States', 3772, 4755, 5854, 6988),
# )
# title = 'MOST ACTIVE BY SHARE VOLUME'
# header = ('Symbol', 'Name', 'Last', 'Change', 'Share Volume')
# data = (
#     ('AMD', 'Advanced Micro Devices, Inc.',
#         '$120.88', '+4.27', '121,475,927'),
#     ('AAPL', 'Apple Inc.', '$164.71', '+1.97', '80,725,613'),
#     ('OPEN', 'Opendoor Technologies Inc', '$8.42', '-2.55', '53,559,847'),
#     ('NVDA', 'NVIDIA Corporation', '$240.82', '+3.34', '49,046,544'),
#     ('ZNGA', 'Zynga Inc.', '$9.18', '+0.37', '48,193,380'),
# )
# title = 'Student Grades'
# header = ('Student ID', 'Test1', 'Test2',
#         'Midterm', 'Quizzes', 'Final')
# data = (
#     (2014255, 55, 78, 63, 50, 80),
#     (2014301, 83, 45, 88, 52, 47),
#     (2014023, 75, 70, 42, 74, 63),
#     (2014155, 67, 87, 54, 87, 86),
# )
#ex15(title, header, data, "ext15_1.txt")

def ex16(lst):
    # Complete this function to use list comprehension to return all values from `lst`
    # that are a multiple of 3 or 4. Just complete the list comprehension below.
    # input: `lst` of numbers
    # output: a list of numbers
    
    # BEGIN SOLUTION
    # complete the following line!
    # return [for ele in lst] #complete this line!
    # remove this line
    return [ele for ele in lst if ele%3 == 0 or ele%4 == 0]
    # END SOLUTION
#print(ex16(range(1, 20)))


def ex17(lst):
    # Complete this function to use list comprehension to multiple all numbers
    # in the list by 3 if it is even or 5 if its odd
    # input: `lst` of numbers
    # output: a list of numbers


    # BEGIN SOLUTION
    # complete the following line!
    # return [for ele in lst] #complete this line!
    # remove this line
    return [(ele* 3) if ele%2 == 0 else (ele*5) for ele in lst]
    # END SOLUTION
#print(ex17(range(200, 220)))

def ex18(input_dict, test_value):
    # Complete this function to find all the keys in a dictionary that map to the input value. 
    # input1: input_dict (dict)
    # input2: test_value
    # output: list of keys

    # BEGIN SOLUTION
    return [key for key,value in input_dict.items() if value == test_value]
    # END SOLUTION
'''input_dict = {
            'January': 31,
            'February': 28,
            'March': 31,
            'April': 30,
            'May': 31,
            'June': 30,
            'July': 31,
            'August': 31,
            'September': 30,
            'October': 31,
            'November': 30,
            'December': 31,
        }'''
#print(ex18(input_dict, 31))

def ex19(filename):
    """
    In this problem you will read data from a file and perform a simple mathematical operation on each data point. 
    Each line is supposed to contain a floating point number.
    But what you will observe is that some lines might have erroneous entries. 
    You need to ignore those lines (Hint: Use Exception handling).

    The idea is to implement a function which reads in a file and computes the median 
    of the numbers and returns the output. You may use the inbuilt function sort when computing the median.

    DO NOT USE ANY INBUILT OR OTHER FUNCTION TO DIRECTLY COMPUTE MEDIAN

    The files
    """
    ### BEGIN SOLUTION
    import math
    file = open(filename,"r")
    value = [];  count = 0
    for f in file.readlines():
        if f != '\n':
            count += 1
            try:
                if(float(f)):
                    value.append(float(f))
            except:
                pass
                # return "The file does not have any valid number to compute the median"
    if value:
        value.sort()
        mid = len(value)//2
        return round((value[mid] + value[~mid]) / 2,6)
    else:
        return "The file does not have any valid number to compute the median"
    ### END SOLUTION
#print(ex19("ex19_data_1.txt"))

def simulateProblem():
    """
    See instructions in exercise_19_instructions.html file
    """
    ### BEGIN SOLUTION
    import random

    outcomes = random.choice((('A', '2A'),('2A', 'A')))
    option = random.choice(('stick','switch'))
    event = random.choice(outcomes)
    if event == 'A':
        if option == 'stick': return (False, False)
        elif option == 'switch': return (True, False)
    elif event == '2A':
        if option == 'stick': return (True, True)
        elif option == 'switch': return (False, True)
    ### END SOLUTION


def ex20():
    """
    The function calls the simulateProblem() 10000 times to figure out 
    the empirical (observed) probability of gaining more money when switching 
    and gaining more money when sticking to the original choice.
    Return the probability of win due to sticking and win due to switching
    """
    ### BEGIN SOLUTION
    iterations = 1000
    win_lose =False; stick_switch = False; win_stick = 0; win_switch = 0; 
    for i in range(iterations):
        win_lose, stick_switch = simulateProblem()
        if win_lose:
            if stick_switch:
                win_stick += 1
            elif stick_switch == False:
                win_switch += 1
    return (win_stick/iterations, win_switch/iterations)
    ### END SOLUTION
print(ex20())